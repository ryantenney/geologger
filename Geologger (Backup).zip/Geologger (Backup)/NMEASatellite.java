/*	NMEASatellite.java

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

public class NMEASatellite
{
	public enum Mode
	{
		LINEAR, SINE, LOG, SQRT;
	}
	
	private String prn;
	private int elev, azim, snr;
	
	public NMEASatellite()
	{
		prn = "";
		elev = 0;
		azim = 0;
		snr = 0;
	}
	
	public String getPRN()
	{
		return prn;
	}
	
	public void setPRN( String value )
	{
		prn = value;
	}
	
	public int getElevation()
	{
		return elev;
	}
	
	public void setElevation( int value )
	{
		elev = value;
	}
	
	public int getAzimuth()
	{
		return azim;
	}

	public void setAzimuth( int value )
	{
		azim = value;
	}
	
	public int getSNR()
	{
		return snr;
	}
	
	public void setSNR( int value )
	{
		snr = value;
	}
	
	public boolean isTracking()
	{
		return snr == 0;
	}
	
	public double getMapX()
	{
		return getMapX( Mode.LINEAR );
	}
	
	public double getMapX( Mode mode)
	{
		return getRadius( mode ) * Math.sin( Math.toRadians( azim ) );
	}
	
	public double getMapY()
	{
		return getMapY( Mode.LINEAR );
	}
	
	public double getMapY( Mode mode )
	{
		return getRadius( mode ) * Math.cos( Math.toRadians( azim ) );
	}
	
	public double getRadius()
	{
		return getRadius( Mode.LINEAR );
	}
	
	public double getRadius( Mode mode )
	{
		switch( mode )
		{
			default:
			case LINEAR:
				return 1 - ( elev / 90.0 );
			case SINE:
				return Math.cos( Math.toRadians( elev ) );
			case LOG:
				return Math.log( 90 - elev ) / Math.log( 90.0 );
			case SQRT:
				return Math.sqrt( 90 - elev ) / Math.sqrt( 90.0 );
		}
	}
	
	public double getMapZ()
	{
		return Math.cos( Math.toRadians( elev ) );
	}
}
