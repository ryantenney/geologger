/*	BTQ1000.java

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

/*	PMTK Packets
 
	Info Set 1:
	$PMTK182,2,3*
	$PMTK182,2,4*
	$PMTK182,2,5*

	Info Set 2:
	$PMTK182,2,7*
	$PMTK182,2,8*
	$PMTK182,2,10*
	$PMTK182,7,001F0000,2*

	Erase:
	$PMTK182,6,1*

	Download:
	$PMTK182,7,00000000,00010000*
 */

import java.awt.event.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;

public class BTQ1000 extends NMEA
{
	public enum ConnectionMode
	{
		USB, BLUETOOTH;
	}
	
	public enum LogFormat
	{
		XML, KML, CSV, BIN, NMEA;
	}
	
	// Constants
	private final static String bluetoothPort = "/dev/cu.iBT-GPS";
	private final static String usbPort = "/dev/cu.SLAB_USBtoUART";
	
	// Variables
	private byte[] logData;
	private boolean[] blockStatus;
	private int bytesComplete;
	private LinkedList< NMEASentence > dataRequests;
	private File logFile;
	private LogFormat logFormat;
	
	public BTQ1000()
	{
		super();
		initArrays();
	}
	
	public BTQ1000( ConnectionMode deviceConnection )
	{
		super();
		initArrays();
		connect( deviceConnection );
	}
	
	protected void initArrays()
	{
		logData = new byte[ 0x00200000 ];
		blockStatus = new boolean[ 0x00200000 ];
		bytesComplete = 0;

		dataRequests = new LinkedList();

		Arrays.fill( logData, 0x00000000, 0x00200000, (byte)0x00 );
		Arrays.fill( blockStatus, 0x00000000, 0x00200000, false );
	}
	
	public void connect( ConnectionMode deviceConnection )
	{
		switch( deviceConnection )
		{
			case USB:
				super.connect( usbPort, 115200 );
				break;
			case BLUETOOTH:
				super.connect( bluetoothPort );
				break;
		}
	}
	
	protected void populateVerbs()
	{
		super.populateVerbs();
		verbs.put( new PMTK() );
	}
	
	public void beginDownloadLogData( File file, LogFormat format )
	{
		final int interval = 0x00010000;
		
		initArrays();
		
		logFile = file;
		logFormat = format;
		
//		for( int offset = 0x00000000; offset < 0x00200000; offset += interval )
//		{ 
//			dataRequests.add( new NMEASentence( "PMTK182", new String[] { "7", formatHex( offset ), formatHex( interval ) } ) );
			dataRequests.add( new NMEASentence( "PMTK182", new String[] { "7", formatHex( 0x00000000 ), formatHex( 0x00200000 ) } ) );
//		}

		sendSentence( dataRequests.poll() );
	}
	
	public void eraseDevice()
	{
		sendSentence( new NMEASentence( "PMTK182", new String[] { "6", "1" } ) );
	}
	
	public int getDownloadProgress()
	{
		return bytesComplete;
	}
	
	protected String formatHex( int hex )
	{
		return String.format( "%1$08X", hex );
	}
	
	public void verbEvent( String verb, Object[] args )
	{
//		System.out.println( String.format( "Verb: %s, Argc: %d, Argv[ 0 ] type: %s", verb, args.length,
//										   ( args.length >= 1 && args[ 0 ] != null) ? args[ 0 ].getClass().getName() : "NULL" ) );
		if( verb.equals( "PMTK" ) && args.length >= 1 && args[ 0 ] instanceof PMTK.DataPacket )
		{
			PMTK.DataPacket data = ( PMTK.DataPacket ) args[ 0 ];
			System.arraycopy( data.getData(), 0, logData, data.getOffset(), data.getLength() );
			Arrays.fill( blockStatus, data.getOffset(), data.getOffset() + data.getLength(), true );
			bytesComplete += data.getLength();
//			if( bytesComplete % 0x00010000 == 0 && dataRequests.peek() != null )
//			{
//				sendSentence( dataRequests.poll() );
//			}
			if( bytesComplete == 0x00200000 )
			{
				try
				{
//					convertLog( logData, LogFormat.BIN, LogFormat.KML );
					FileOutputStream fos = new FileOutputStream( logFile );
					fos.write( logData );
					fos.flush();
					fos.close();
				}
				catch( IOException ioex )
				{
					ioex.printStackTrace();
				}
			}
		}
		else
		{
			super.verbEvent( verb, args );
		}
	}
	
	public boolean isComplete()
	{
		boolean retval = blockStatus[ 0 ];
		for( int i = 1; i < blockStatus.length; ++i )
		{
			retval &= blockStatus[ i ];
			if( retval == false ) { break; }
		}
		return retval;
	}
	
}
