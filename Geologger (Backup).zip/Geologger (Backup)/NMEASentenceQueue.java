/*	NMEASentenceQueue.java

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

import java.util.*;
import java.util.concurrent.*;

public abstract class NMEASentenceQueue extends Thread
{
	private ArrayBlockingQueue< NMEASentence > queue;

	private long bytes, processedSentences, maxTime, totalTime;
		
	public NMEASentenceQueue( int size )
	{
		queue = new ArrayBlockingQueue< NMEASentence >( size );
	}	
	
	protected NMEASentence take() throws InterruptedException
	{
		// variable to hold the amount of time sentence was in queue
		long time;
		
		// take new sentence, or wait until one is available
		NMEASentence retVal = queue.take();
		
		synchronized( retVal )
		{
			// mark the time the sentence is taken
			time = retVal.taken();
		}
		
		// keep stats on sentences and time in queue
		++processedSentences;
		if( retVal.getTimeOffered() != -1 && retVal.getTimeTaken() != -1 )
		{
			totalTime += time;
			bytes += retVal.length();
			if( time > maxTime)
			{
				maxTime = time;
			}
		}

		return retVal;
	}
	
	protected boolean offer( NMEASentence obj )
	{
		synchronized( obj )
		{
			boolean retVal = queue.offer( obj );
			if( retVal ) { obj.offered(); }
			return retVal;
		}
	}

	protected boolean offer( NMEASentence obj, long timeout, TimeUnit unit ) throws InterruptedException
	{
		synchronized( obj )
		{
			boolean retVal = queue.offer( obj, timeout, unit );
			if( retVal ) { obj.offered(); }
			else { System.out.println( "offer failed: " + obj.getSentence().substring( 0, obj.length() > 32 ? 30 : obj.length() - 2 ) );}
			return retVal;
		}
	}
	
	public void beginAsync()
	{
		this.start();
	}
	
	public void endAsync()
	{
		this.stop();
	}
	
	public long getProcessedCount()
	{
		return processedSentences;
	}
	
	public long getQueueTimeMax()
	{
		long oldest = getOldest();
		if( oldest > maxTime ) { maxTime = oldest; }
		return maxTime;
	}
	
	public float getQueueTimeAvg()
	{
		float divisor = (float)totalTime;
		float dividend = (float)processedSentences;
		return divisor / dividend;
	}
	
	public int getQueueLength()
	{
		return queue.size();
	}
	
	public long getOldest()
	{
		long oldest = 0;
		synchronized( queue )
		{
			NMEASentence top = queue.peek();
			
			if( top != null )
			{
				oldest = System.currentTimeMillis() - top.getTimeOffered();
			}
		}
		return oldest;
	}
	
	public long getBytes()
	{
		return bytes;
	}
	
}
