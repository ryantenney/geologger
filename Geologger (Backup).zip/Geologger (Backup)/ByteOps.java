/*	ByteOps.java

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

import java.util.*;

public class ByteOps
{

	public static boolean compareByte( int b1, int b2 )
	{
		return ( b1 & 0xFF ) == ( b2 & 0xFF );
	}

	public static boolean compareByte( int b1, int b2, int mask )
	{
		return ( ( b1 & mask ) & 0xFF ) == ( ( b2 & mask ) & 0xFF );
	}

	public static String byteToHexString( int value )
	{
		String b = Integer.toHexString( value & 0xFF ).toUpperCase();
		return b.length() == 1 ? "0" + b : b;
	}
	
	public static String byteToHexString( byte[] value )
	{
		String s = "";
		for( byte b : value )
		{
			s = s + byteToHexString( b );
		}
		return s;
	}
	
	/*
	 Functions designed to read the reversed 
	 */
	
	public static byte readByte( byte[] data, int offset ) throws ArrayIndexOutOfBoundsException
	{
		return data[ offset ];
	}
	
	public static int readUnsignedByte( byte[] data, int offset ) throws ArrayIndexOutOfBoundsException
	{
		return data[ offset ] & 0xFF;
	}
	
	public static short readShort( byte[] data, int offset ) throws ArrayIndexOutOfBoundsException
	{
		int retVal = data[ offset ] & 0xFF;
		retVal |= ( data[ ++offset ] & 0xFF ) << 8;
		return (short)retVal;
	}
	
	public static int readUnsignedShort( byte[] data, int offset ) throws ArrayIndexOutOfBoundsException
	{
		return readShort( data, offset ) & 0xFFFF;
	}
	
	public static int readInt( byte[] data, int offset ) throws ArrayIndexOutOfBoundsException
	{
		int shift = 0;
		int retVal = data[ offset ] & 0xFF;
		retVal |= ( data[ ++offset ] & 0xFF ) << ( ++shift * 8 );
		retVal |= ( data[ ++offset ] & 0xFF ) << ( ++shift * 8 );
		retVal |= ( data[ ++offset ] & 0xFF ) << ( ++shift * 8 );
		return retVal;
	}
	
	public static long readUnsignedInt( byte[] data, int offset ) throws ArrayIndexOutOfBoundsException
	{
		return readInt( data, offset ) & 0xFFFFFFFF;
	}
	
	public static float readFloat( byte[] data, int offset ) throws ArrayIndexOutOfBoundsException
	{
		return Float.intBitsToFloat( readInt( data, offset ) );
	}
	
	public static long readLong( byte[] data, int offset ) throws ArrayIndexOutOfBoundsException
	{
		int shift = 0;
		int retVal = data[ offset ] & 0xFF;
		retVal |= ( data[ ++offset ] & 0xFF ) << ( ++shift * 8 );
		retVal |= ( data[ ++offset ] & 0xFF ) << ( ++shift * 8 );
		retVal |= ( data[ ++offset ] & 0xFF ) << ( ++shift * 8 );
		retVal |= ( data[ ++offset ] & 0xFF ) << ( ++shift * 8 );
		retVal |= ( data[ ++offset ] & 0xFF ) << ( ++shift * 8 );
		retVal |= ( data[ ++offset ] & 0xFF ) << ( ++shift * 8 );
		retVal |= ( data[ ++offset ] & 0xFF ) << ( ++shift * 8 );
		return retVal;
	}
	
	public static double readDouble( byte[] data, int offset ) throws ArrayIndexOutOfBoundsException
	{
		return Double.longBitsToDouble( readLong( data, offset ) );
	}

}
