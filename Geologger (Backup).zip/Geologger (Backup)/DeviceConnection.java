/*	DeviceConnection.java

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation; either version 3 of the License, or
	(at your option) any later version.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

import java.util.*;
import java.util.concurrent.*;

public class DeviceConnection implements Runnable
{	
	
	public enum State
	{
		ASYNC( 2 ),
		OPEN( 1 ),
		CLOSED( 0 ),
		FAILED( -1 ),
		CLOSING( -2 ),
		ATEOF( -3 ),
		ERROR( -4 );
		
		private int stateId;
		
		State( int value ) { stateId = value; }
		
		State() { stateId = 0; }
		
		int getValue() { return stateId; }
		
		static State getState( int value )
		{
			switch( value )
			{
				case 2:		return ASYNC;
				case 1:		return OPEN;
				default:
				case 0:		return CLOSED;
				case -1:	return FAILED;
				case -2:	return CLOSING;
				case -3:	return ATEOF;
				case -4:	return ERROR;
			}
		}
	}
	
	private native void open( String port );
	private native void puts( String data );
	private native String gets();
	private native void startGetsAsync();
	private native void endGetsAsync();
	private native void setBaud( int baudrate );
	private native int getBaud();
	private native void close();
	private native int getState();

	private int lastState;
	
	private Thread async;
	private final Set< DeviceListener > callbacks;
	
	public DeviceConnection()
	{
		Set< DeviceListener > temp = new HashSet< DeviceListener >();
		callbacks = Collections.synchronizedSet( temp );
	}
	
	public void connect( String port )
	{
		open( port );
	}

	public void connect( String port, int baudrate )
	{
		open( port );
		setBaud( baudrate );
	}
	
	public void disconnect()
	{
		close();
	}

	public void beginReceiveAsync()
	{
		if( async == null && getState() == 1 )
		{
			async = new Thread( this, "DeviceConnection::ReceiveAsync" );
			async.start();
		}
	}
	
	public void endReceiveAsync()
	{
		if( async != null && getState() == 2 )
		{
			endGetsAsync();
			async = null;
		}
	}
	
	public void addDeviceListener( DeviceListener listener )
	{
		if( listener != null )
		{
			callbacks.add( listener );
		}
	}
	
	public void removeDeviceListener( DeviceListener listener )
	{
		callbacks.remove( listener );
	}
	
	private void deviceDataEvent( final int len, final String data )
	{
		final DeviceConnection finalThis = this;
		
		// anonymous class
		new Thread( new Runnable() {
			public synchronized void run()
			{
				for( DeviceListener listener : callbacks )
				{
					if( listener != null )
					{
						listener.deviceDataEvent( finalThis, len, data );
					}
					else
					{
						callbacks.remove( listener );
					}
				}
			}
		}, "DeviceConnection::deviceDataEvent" ).start();
	}
	
	private void deviceStateEvent( final int state )
	{
		lastState = state;
		
		final DeviceConnection finalThis = this;
		
		// anonymous class
		new Thread( new Runnable() {
			public synchronized void run()
			{
				for( DeviceListener listener : callbacks )
				{
					if( listener != null )
					{	
						listener.deviceStateEvent( finalThis, State.getState( state ) );
					}
					else
					{
						callbacks.remove( listener );
					}
				}
			}
		}, "DeviceConnection::deviceStateEvent" ).start();
	}
		
	public void send( String data )
	{
		puts( data );
	}
	
	public State getDeviceState()
	{
		return State.getState( lastState );
	}
	
	public int getBaudRate()
	{
		return getBaud();
	}
	
	public void setBaudRate( int value )
	{
		setBaud( value );
	}
	
	public void run()
	{
		startGetsAsync();
	}
	
	static
	{
		System.loadLibrary( "DeviceConnection" );
	}

}